import 'package:flutter/material.dart';
import 'package:laptop_harbor/screens/register.dart';
import 'package:laptop_harbor/services/auth.dart';

class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    if (!AuthService.instance().isLoggedIn()) {
      Navigator.of(context).pushNamed('/register');
    }
    else {
      Navigator.of(context).pushNamed('/home');
    }

    return Text("Loading...");
  }
}